def linha(caractere):
  print(caractere * 100)